from flask import Flask, render_template, request

app = Flask(__name__)

yemekler = {
    ("turkiye", "vegan", "firin"): ("Zeytinyağlı Enginar", "enginar.jpg"),
    ("turkiye", "vegan", "kizartma"): ("Baharatlı Balkabağı", "balkabagi.jpg"),
    ("turkiye", "vegan", "haslama"): ("Kuru Dolma", "sarma.jpg"),
    ("turkiye", "vejetaryen", "firin"): ("Fırında Karnabahar", "karnabahar.jpg"),
    ("turkiye", "vejetaryen", "kizartma"): ("Mantar Sote", "mantar.jpg"),
    ("turkiye", "vejetaryen", "haslama"): ("Balkabağı Çorbası", "corba.jpg"),
    ("turkiye", "pesketaryen", "firin"): ("Fırında Uskumru", "uskumru.jpg"),
    ("turkiye", "pesketaryen", "kizartma"): ("Karides Güveç", "karides.jpg"),
    ("turkiye", "pesketaryen", "haslama"): ("Balık Buğulama", "bugulama.jpg"),
    ("turkiye", "hepcil", "firin"): ("Fırında Kuzu İncik", "kuzu.jpg"),
    ("turkiye", "hepcil", "kizartma"): ("İçli Köfte", "iclikofte.jpg"),
    ("turkiye", "hepcil", "haslama"): ("Hünkar Beğendi", "begendi.jpg"),
}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/sonuc', methods=['POST'])
def sonuc():
    ulke = request.form.get('ulke')
    tarz = request.form.get('tarz')
    pisirme = request.form.get('pisirme')
    secim = yemekler.get((ulke, tarz, pisirme))
    if secim:
        yemek, gorsel = secim
    else:
        yemek = None
        gorsel = None
    return render_template('sonuc.html', yemek=yemek, gorsel=gorsel)

if __name__ == '__main__':
    app.run(debug=True)
